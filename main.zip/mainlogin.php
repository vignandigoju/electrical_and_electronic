<?php
$conn = mysqli_connect("localhost", "root", "", "maintanence");
session_start();

if (!empty($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $query = "SELECT * FROM login WHERE username='" . $username . "' AND password='" . $password . "'";
    $result = mysqli_query($conn, $query);
    
    // Check if the query returned any rows
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);
        if ($row["role"] == 'manager') {
            $_SESSION["username"] = $username;
            header('location: appdashboard.php');
        } elseif ($row["role"] == 'supervisor') {
            $_SESSION["username"] = $username;
            header('location: supervisordashboard.php');
        } elseif ($row["role"] == 'worker') {
            $_SESSION["username"] = $username;
            header('location: workerpage.php');
        }

    } else {
        // Display a pop-up message for invalid username/password
        echo '<script>alert("Invalid username or password");</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Electrical Equipment Maintenance</title>
    <style>
        body {
            max-width: max-content;
            margin: auto;
            margin-Top: 80px;
            background-color: #BDEEC5;
            font-size: 1.3em;
        }

        label {
            display: inline-block;
            width: 90px;
        }

        #btn_s {
            width: 300px;
            height: 35px;
            background-color: #BDEEC5;
            font-size: 16px;
            font-face: bold;

        }

        #btn_i {
            width: 125px;
        }
    </style>
</head>
<body style="background-color: 3F3064;">
<p id="ground">
    <center>
        <br>
        <form method="post">
            <fieldset style="padding: 50px; border: 1px solid white; background: #f6f8ff; align: center;">
                <h4>Login</h4>
                <img
                        src="https://img.freepik.com/free-vector/illustration-characters-fixing-cogwheel_53876-40796.jpg?w=740&t=st=1693233930~exp=1693234530~hmac=89614fb179ec99424a33687e09d36c7e3be27565e51a41e8288d23158d5ae7f6"
                        width="150" height="150" style="background-color: transparent;">
                <div id="page">
                    <label for="username">Username:</label>
                    <input type="text" name="username" required><br><br>
                    <label for="password">Password:</label>
                    <input type="password" id="pass" name="password" required><br><br>
                    <input type="submit" name="submit" value="login">
                </div>
            </fieldset>
        </form>
    </center>
</p>
<script>
    function togglePasswordVisibility() {
        var passwordField = document.getElementById("pass");
        if (passwordField.type === "password") {
            passwordField.type = "text";
        } else {
            passwordField.type = "password";
        }
    }
    
    // Add JavaScript code to reload the page after the pop-up is dismissed
    var popUpMessage = document.querySelector('script');
    if (popUpMessage) {
        popUpMessage.addEventListener('click', function() {
            window.location.reload();
        });
    }
</script>
</body>
</html>
