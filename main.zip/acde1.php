<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }
        .NEXT-button {
            background-color: #1c0d3f; 
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<div class="container">
    <?php
$conn = mysqli_connect("localhost", "root", "", "maintanence");
session_start();
$sql = "SELECT name, type, price, installation, warranty, warrantyend FROM eqdetails WHERE eid=5001";
$result = mysqli_query($conn, $sql);
if ($result) {
    $row = mysqli_fetch_assoc($result);
     $name = $row['name'];
     $type = $row['type'];
     $price = $row['price'];
     $installation = $row['installation'];
     $warranty = $row['warranty'];
     $warrantyend = $row['warrantyend'];
     //echo $name;
    echo '<h1>Equipment Details</h1><br></br>';
    echo '<tr><td>Name:</td> <td>'.$name.'</td></tr><br></br>';
    echo '<tr><td>Type:</td> <td>'.$type.'</td></tr><br></br>';
    echo '<tr><td>Price:</td> <td>'.$price.'</td></tr><br></br>';
    echo '<tr><td>Installation:</td> <td>'.$installation.'</td></tr><br></br>';
    echo '<tr><td>Warranty:</td> <td>'.$warranty.'</td></tr><br></br>';
    echo '<tr><td>Warranty End:</td> <td>'.$warrantyend.'</td></tr><br></br>';
}

    ?>

<h2>Job History</h2>
<style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
    }

    td:not(:last-child) {
        border-right: 1px solid #ddd;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
</style>

<table>
    <thead>
        <tr>
            <th>Service Type</th>
            <th>Service Charge</th>
            <th>Date</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $conn = mysqli_connect("localhost", "root", "", "maintanence");
        $sql = "SELECT servicetype, servicecharge, date, status FROM job WHERE eid2=5001";
        $result = mysqli_query($conn, $sql);
        
        while ($row = mysqli_fetch_assoc($result)) {
            $servicetype = $row['servicetype'];
            $servicecharge = $row['servicecharge'];
            $date = $row['date'];
            $status = $row['status'];
            echo '<tr>';
            echo '<td>' . $servicetype . '</td>';
            echo '<td>' . $servicecharge . '</td>';
            echo '<td>' . $date . '</td>';
            echo '<td>' . $status . '</td>';
            echo '</tr>';
        }
        ?>
    </tbody>
</table>


    <center>
    <p><a href="acwork1.php"><button class="NEXT-button">Next</button></a></p>
    </center>
</body>
</html>
