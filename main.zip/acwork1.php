<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment Details</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        .job-history {
            list-style: none;
            padding-left: 0;
        }

        .job-history li {
            border: 1px solid #ddd;
            padding: 10px;
            margin-bottom: 10px;
        }

        .job-history li strong {
            font-weight: bold;
        }

        .assign-button {
            background-color: #1c0d3f;
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .sidenav {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color:#1c0d3f;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }

        .sidenav a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
            transition: 0.3s;
        }

        .sidenav a:hover {
            color: #f1f1f1;
        }

        .sidenav .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        @media screen and (max-height: 450px) {
            .sidenav { padding-top: 15px; }
            .sidenav a { font-size: 18px; }
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const hamburger = document.querySelector(".hamburger");
            const menuItems = document.querySelector(".menu-items");

            hamburger.addEventListener("click", function() {
                menuItems.classList.toggle("show-menu");
            });
        });
    </script>
</head>
<body>
    <!-- Sidenav -->
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="appdashboard.php">Home</a> 
        <a href="profile.php">My Profile</a>
        <a href="mainlogin.php">Logout</a>
    </div>

    <header>
        <div class="menu-bar">
            <span class="hamburger" onclick="openNav()">&#8801;</span>
        </div>
    </style>
</head>
    </style>
</head>
<body>
    <div class="container">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "maintanence");
        session_start();
        $sql = "SELECT name, type, price, installation, warranty, warrantyend FROM eqdetails WHERE eid=5001";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            $row = mysqli_fetch_assoc($result);
            $name = $row['name'];
            $type = $row['type'];
            $price = $row['price'];
            $installation = $row['installation'];
            $warranty = $row['warranty'];
            $warrantyend = $row['warrantyend'];

            echo '<h1>Equipment Details</h1>';
            echo '<div><strong>Name:</strong> ' . $name . '</div>';
            echo '<div><strong>Type:</strong> ' . $type . '</div>';
            echo '<div><strong>Price:</strong> ' . $price . '</div>';
            echo '<div><strong>Installation:</strong> ' . $installation . '</div>';
            echo '<div><strong>Warranty:</strong> ' . $warranty . '</div>';
            echo '<div><strong>Warranty End:</strong> ' . $warrantyend . '</div>';
        }
        ?>

        <?php
        $conn = mysqli_connect("localhost", "root", "", "maintanence");
        $sql = "SELECT servicetype, servicecharge, empid, date, status FROM job WHERE eid2=5001";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            echo '<h2>Job History</h2>';
            while ($row = mysqli_fetch_assoc($result)) {
                $servicetype = $row['servicetype'];
                $servicecharge = $row['servicecharge'];
                $empid = $row['empid'];
                $date = $row['date'];
                $status = $row['status'];

                echo '<div class="job-history">';
                echo '<li>';
                echo '<strong>Service Type:</strong> ' . $servicetype;
                echo '<br>';
                echo '<strong>Service Charge:</strong> ' . $servicecharge;
                echo '<br>';
                echo '<strong>Employee Id:</strong> ' . $empid;
                echo '<br>';
                echo '<strong>Date:</strong> ' . $date;
                echo '<br>';
                echo '<strong>Status:</strong> ' . $status;
                echo '</li>';
                echo '</div>';
            }
        }
        ?>
        </script>
    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
        function showPopup(message) {
            alert(message);
        }
    </script>

    </div>
</body>
</html>
